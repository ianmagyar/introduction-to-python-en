import random


fair_die = [1, 2, 3, 4, 5, 6]


def craps(die1, die2):
    d1 = random.choice(die1)
    d2 = random.choice(die2)
    total = d1 + d2
    if total in [7, 11]:
        return True
    if total in [2, 3, 12]:
        return False
    point = total
    while True:
        d1 = random.choice(die1)
        d2 = random.choice(die2)
        total = d1 + d2
        if total == 7:
            return False
        if total == point:
            return True


def simCraps(numGames, die1, die2):
    wins, losses = 0, 0
    for i in range(numGames):
        if craps(die1, die2):
            wins += 1
        else:
            losses += 1
    print("House wins {} times".format(losses))
    print("House loses {} times".format(wins))
    print("House winning percentage: {}%".format(100 * losses / numGames))
    print("House profits {}$ after {} games".format(losses - wins, numGames))


unfair_die = [1, 2, 3, 4, 5, 6]

simCraps(1000000, fair_die, fair_die)
