class Auditorium:
    def __init__(self, capacity):
        self.capacity = capacity
        self.screenings = list()

    def is_available(self, new_screening):
        return False

    def add_screening(self, new_screening):
        return False


if __name__ == '__main__':
    # you can run your tests here
    pass
