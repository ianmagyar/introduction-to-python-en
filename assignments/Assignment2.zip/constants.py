GENRES = [
    'action',
    'adventure',
    'animated',
    'comedy',
    'drama',
    'fantasy',
    'historical',
    'horror',
    'musical',
    'noir',
    'romance',
    'sci-fi',
    'thriller',
    'western'
]
