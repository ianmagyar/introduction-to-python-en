class Plane:
    def __init__(self, length):
        self.length = length
        self.seats = [[[] for i in range(self.length + 2)] for j in range(7)]

    def print_plane(self):
        # TODO - optional
        pass

    def add_passengers(self, psg_list):
        # TODO
        pass

    def is_empty(self, row, seat):
        # TODO
        return True

    def move_row(self, row, seat_letter):
        # TODO
        pass

    def return_row(self, row):
        # TODO
        pass

    def move_passengers(self):
        # TODO
        pass

    def boarding_finished(self):
        # TODO
        return True
