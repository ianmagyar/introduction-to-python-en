CATEGORIES = ["politics", "world", "culture", "tech", "local", "sport"]


class News:
    def __init__(self, category, excitement_rate, validity_length, created):
        self.check_data(category, excitement_rate, validity_length, created)

        self.category = category
        self.excitement_rate = excitement_rate
        self.validity_length = validity_length
        self.created = created

    def check_data(self, category, excitement_rate, validity_length, created):
        pass

    def get_excitement(self, time_step):
        return
