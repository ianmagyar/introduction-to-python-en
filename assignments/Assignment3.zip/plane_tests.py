from random import randint

from plane import Plane
from passenger import Passenger


def test_add_passengers():
    print("Plane - testing add_passengers():")
    psg_list = [
        Passenger(4, "A", 0),
        Passenger(4, "B", 0),
        Passenger(4, "C", 0),
        Passenger(4, "D", 0),
        Passenger(4, "E", 0),
        Passenger(4, "F", 0),
    ]

    plane = Plane(8)

    plane.add_passengers(psg_list)

    assert len(psg_list) == len(plane.seats[3][0]), "\tAll passengers should be added to position [3, 0]"

    for psg in psg_list:
        assert psg.plane is plane, "\tPlane attribute should be updated for all passengers"
        pos_i, pos_j = psg.current_position
        assert pos_i == 0 and pos_j == 3, "\tPassenger's position should be updated to [0, 3], got [{}, {}]".format(pos_i, pos_j)

    print("Plane - testing add_passengers() finished; correct solution")


def test_is_empty():
    print("Plane - testing is_empty():")

    psg = Passenger(4, "D", 0)
    plane = Plane(8)

    # test for non-existing position
    assert plane.is_empty(0, 15) is True, "\tMethod should return True for non-existing positions"


    for x in range(5):
        seat = randint(0, 6)
        row = randint(0, 9)

        assert plane.is_empty(row, seat) is True, "\tMethod should return True for seat not taken"

    for x in range(5):
        seat = randint(0, 6)
        row = randint(0, 9)

        plane.seats[seat][row].append(psg)

        assert plane.is_empty(row, seat) is False, "\tMethod should return False for seat taken"

    print("Plane - testing is_empty() finishedl correct solution")


def test_move_row():
    print("Plane - testing move_row():")

    plane = Plane(8)

    psg1 = Passenger(2, "E", 0)
    psg1.plane = plane
    psg1.current_position = [2, 1]
    plane.seats[1][2].append(psg1)

    psg2 = Passenger(4, "D", 0)
    psg2.plane = plane
    psg2.current_position = [4, 2]
    plane.seats[2][4].append(psg2)

    psg3 = Passenger(4, "E", 0)
    psg3.plane = plane
    psg3.current_position = [4, 1]
    plane.seats[1][4].append(psg3)

    psg4 = Passenger(7, "A", 0)
    psg4.plane = plane
    psg4.current_position = [7, 6]
    plane.seats[6][7].append(psg4)

    # test for empty row
    plane.move_row(1, 'E')
    assert len(plane.seats[3][2]) == 0, "\tMethod should not move an empty row"

    # test with one person in way
    plane.move_row(2, 'F')
    assert len(plane.seats[3][3]) == 1, "\tMethod should move all passengers sitting in the way"

    # test when next position is blocked
    plane.seats[3][3].clear()
    plane.seats[1][2].append(psg1)
    plane.seats[3][3].append(Passenger(8, "D", 0))

    plane.move_row(2, 'F')
    assert len(plane.seats[3][3]) == 1, "\tMethod should not move passengers when next position is blocked"

    # test with two persons in way
    plane.move_row(4, 'F')
    assert len(plane.seats[3][5]) == 2, "\tMethod should move all passengers sitting in the way"

    # test when no passenger should be moved
    plane.move_row(7, 'B')
    assert len(plane.seats[3][8]) == 0, "\tMethod should not move passengers not in the way"

    print("Plane - testing move_row() finished; correct solution")


def test_return_row():
    print("Plane - testing return_row():")
    plane = Plane(8)

    psg1 = Passenger(1, "E", 0)
    psg2 = Passenger(1, "D", 0)
    plane.seats[3][2].append(psg1)
    plane.seats[3][2].append(psg2)
    psg1.plane = plane
    psg1.current_position = [2, 3]
    psg2.plane = plane
    psg2.current_position = [2, 3]

    plane.return_row(1)
    assert len(plane.seats[3][2]) == 0, "\tMethod should return passengers to their seats"
    assert len(plane.seats[1][1]) == 1, "\tMethod should return passengers to their seats"
    assert len(plane.seats[2][1]) == 1, "\tMethod should return passengers to their seats"

    print("Plane - testing return_row() finished; correct solution")


def test_move_passengers():
    print("Plane - testing move_passengers():")

    plane = Plane(8)

    psg1 = Passenger(1, "E", 0)
    psg1.plane = plane
    psg1.current_position = [1, 3]
    plane.seats[3][1].append(psg1)

    psg2 = Passenger(4, "F", 0)
    psg2.plane = plane
    psg2.current_position = [4, 3]
    plane.seats[3][4].append(psg2)

    psg3 = Passenger(4, "D", 0)
    psg3.plane = plane
    psg3.current_position = [4, 2]
    plane.seats[2][4].append(psg3)

    psg4 = Passenger(4, "E", 0)
    psg4.plane = plane
    psg4.current_position = [4, 1]
    plane.seats[1][4].append(psg4)

    psg5 = Passenger(7, "C", 2)
    psg5.plane = plane
    psg5.current_position = [7, 3]
    plane.seats[3][7].append(psg5)

    psg6 = Passenger(8, "E", 0)
    psg6.plane = plane
    psg6.current_position = [6, 3]
    plane.seats[3][6].append(psg6)

    plane.move_passengers()

    assert len(plane.seats[3][1]) == 0, "\tPSG1 should have been moved to his seat"
    assert len(plane.seats[1][1]) == 1, "\tPSG1 should have been moved to his seat"

    assert len(plane.seats[3][4]) == 1, "\tPSG2 should wait for the path to his seat to clear"
    assert len(plane.seats[3][5]) == 2, "\tPSG3 and PSG4 should have been moved to clear PSG2's path to his seat"

    assert len(plane.seats[3][6]) == 1, "\tPSG6 is stuck, waiting for PSG5 to unload bags"
    assert len(plane.seats[3][7]) == 1, "\tPSG5 has bags to unload, must stay on his position"

    print("Plane - testing move_passengers() finished; correct solution")


def test_boarding_finished():
    print("Plane - testing boarding_finished():")

    # only for simple testing; for boarding, plane's length will be divisible by 4
    plane = Plane(1)

    assert plane.boarding_finished() is False, "\tBoarding should not be finished for empty plane"

    plane.seats[0][1].append(Passenger(1, "F", 0))
    plane.seats[1][1].append(Passenger(1, "E", 0))
    plane.seats[2][1].append(Passenger(1, "D", 0))

    assert plane.boarding_finished() is False, "\tBoarding should not be finished for half-full plane"

    plane.seats[6][1].append(Passenger(1, "A", 0))
    plane.seats[5][1].append(Passenger(1, "B", 0))
    plane.seats[3][1].append(Passenger(1, "C", 0))

    assert plane.boarding_finished() is False, "\tBoarding should not be finished when someone is in the aisle"

    plane.seats[3][1].clear()
    plane.seats[4][1].append(Passenger(1, "C", 0))

    assert plane.boarding_finished() is True, "\tBoarding should be finished when aisle is clear and all seats are taken"
    print("Plane - testing boarding_finished(); correct solution")


def test_plane():
    test_add_passengers()

    test_is_empty()

    test_move_row()

    test_return_row()

    test_move_passengers()

    test_boarding_finished()


if __name__ == '__main__':
    test_plane()
