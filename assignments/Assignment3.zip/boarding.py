class Boarding:
    def __init__(self):
        self.plane = None

    def generate_boarding(self, plane_length):
        # DO NOT IMPLEMENT HERE
        pass

    def run_simulation(self, plane_length):
        # TODO
        return None

    def test_boarding_method(self, plane_length, no_simulation):
        # TODO
        return None, None


class BoardingBTF(Boarding):
    def generate_boarding(self, plane_length):
        # TODO
        pass


class BoardingFTB(Boarding):
    def generate_boarding(self, plane_length):
        # TODO
        pass


class BoardingWTA(Boarding):
    def generate_boarding(self, plane_length):
        # TODO
        pass


class BoardingATW(Boarding):
    def generate_boarding(self, plane_length):
        # TODO
        pass


class BoardingRandom(Boarding):
    def generate_boarding(self, plane_length):
        # TODO
        pass


class BoardingSteffen(Boarding):
    def generate_boarding(self, plane_length):
        # TODO
        pass
